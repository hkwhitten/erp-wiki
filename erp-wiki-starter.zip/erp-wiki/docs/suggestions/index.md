# Suggestions

Ideas to make things better. Explain the benefit and a possible approach.
