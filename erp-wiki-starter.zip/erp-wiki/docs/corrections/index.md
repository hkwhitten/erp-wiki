# Corrections

Documentation or UI text that needs correction. Capture the current and the corrected versions.
