---
type: tip
title: Quick filter on Vendor Bills
area: Purchasing
version: v21+
tags: [tip, purchasing, search]
date: 2025-08-27
reported_by: HKW
---
Use the list page search box with `ref:SUP-` to limit to vendor bills only, then save the filter as a favorite.
