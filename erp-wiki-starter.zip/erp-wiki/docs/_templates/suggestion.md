---
type: suggestion
title: <idea>
area: <module>
impact: <low|med|high>
tags: [suggestion, <module>]
reported_by: <name>
date: YYYY-MM-DD
---
## The Idea
## Why it Helps
## Possible Approach
