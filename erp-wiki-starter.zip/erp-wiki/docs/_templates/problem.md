---
type: problem
title: <what went wrong>
area: <module/subarea>
status: open
priority: P2
version: <app version>
env: <Prod|Reporting|ReportCopy|Sandbox>
tags: [bug, <module>]
reported_by: <name>
date: YYYY-MM-DD
---
## Summary
Short description.

## Steps to Reproduce
1.
2.
3.

## Expected
## Actual
## Workaround
## Attachments / Links
## Resolution
(leave blank until fixed)
