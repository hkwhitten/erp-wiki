---
type: tip
title: <concise title>
area: <Accounting|Purchasing|Sales|Inventory|Training>
version: <e.g., v21.0.1>
tags: [tip, <module>]
date: YYYY-MM-DD
reported_by: <name>
---
## Summary
One-paragraph “how to” or shortcut.

## Steps
1.
2.
3.

## Notes
Links / screenshots / caveats.
